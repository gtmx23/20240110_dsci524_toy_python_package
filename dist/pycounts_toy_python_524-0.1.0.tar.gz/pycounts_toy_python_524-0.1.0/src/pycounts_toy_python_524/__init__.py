# read version from installed package
from importlib.metadata import version
__version__ = version("pycounts_toy_python_524")